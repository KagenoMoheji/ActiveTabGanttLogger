__copyright__ = "Copyright (C) 2019 KagenoMoheji"
__version__ = '0.1.0'
__license__ = "MIT"
__author__ = "Goki Sugimura(KagenoMoheji)"
__author_email__ = 'shadowmoheji.pd@gmail.com'
__url__="https://github.com/KagenoMoheji/GanttLogger"
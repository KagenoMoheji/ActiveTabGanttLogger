# GanttLogger
- [README.md - 日本語バージョン](https://github.com/KagenoMoheji/GanttLogger/blob/master/README-ja.md)








## In the future...
- Implement mode remote 'observer' and 'logger/plotter'.
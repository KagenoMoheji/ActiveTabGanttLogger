import sys
import pickle
import matplotlib.pyplot as plt
from ganttlogger.modules.Public import StrFormatter

class Displayer:
    '''
    Reference:
        http://kuroneko0208.hatenablog.com/entry/2014/07/28/161453
    '''
    strfmr = None
    filename = ""
    def __init__(self):
        self.strfmr = StrFormatter()
        self.filename = ""

    def start(self):
        while True:
            print(self.strfmr.get_colored_console_log("yellow",
                    "Input file name of '.pkl': "), end="")
            self.filename = input().strip()
            if not self.filename:
                print(self.strfmr.get_colored_console_log("red",
                    "Error: Invalid input."))
                continue
            if not ".pkl" in self.filename:
                self.filename += ".pkl"
            break
        self.display()
    
    def display(self):
        try:
            with open(self.filename, "rb") as f:
                fig = pickle.load(f)
            plt.show()
        except FileNotFoundError:
            print(self.strfmr.get_colored_console_log("red",
                "Error: File not found."))
            sys.exit()